
#ifndef __HUAWEIIOT_H
#define __HUAWEIIOT_H

///////////////////////////////////////////////////////////
/*ͷ�ļ�������*/
#include "sys.h"
///////////////////////////////////////////////////////////
/*�궨����*/
//ʹ��ʱ�������ﲹȫ�����Ϣ
#define WIFI_SSID									"8266"
#define WIFI_PWD									"123456789"

#define HUAWEI_MQTT_USERNAME			"6795b7d7ef99673c8ae3a91c_humidity_Sensor"
#define HUAWEI_MQTT_PASSWORD			"6be391b2920943bb6ef9d544447d6a831e914517f24ec2aa03165605e33500ef"
#define HUAWEI_MQTT_ClientID			"6795b7d7ef99673c8ae3a91c_humidity_Sensor_0_0_2025030813"

#define HUAWEI_MQTT_ADDRESS				"ab2d07546a.st1.iotda-device.cn-north-4.myhuaweicloud.com"
#define HUAWEI_MQTT_PORT					"1883"

#define HUAWEI_MQTT_DeviceID			"6795b7d7ef99673c8ae3a91c_humidity_Sensor"
#define HUAWEI_MQTT_ServiceID			"BasicData"
#define HUAWEI_MQTT_ServiceID2			"waterListenControl"

///////////////////////////////////////////////////////////
/*�ⲿ����������*/

///////////////////////////////////////////////////////////
/*����������*/
void AT_write(char atstring[512]);//�����ȴ�OK
void HuaweiIot_init(void);
void HuaweiIot_DevDate_publish(char * att,uint16_t data);
///////////////////////////////////////////////////////////
#endif
